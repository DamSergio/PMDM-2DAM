package com.example.sharemybike.dto;

import java.util.ArrayList;
import java.util.Date;

public class BikesContent {
    public static ArrayList<Bike> ITEMS = new ArrayList<>();
    public static String date = new Date().toString();
}
