package com.serbalced.pruebaintent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    public final int SELECCIONA_PROVINCIA = 1;
    public final int RESULTADO_SELECCION_PROVINCIA = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btnProv = findViewById(R.id.btnProv);
        btnProv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrancarProv();
            }
        });
    }

    public void arrancarProv(){
        Intent intentProv = new Intent(getApplicationContext(), ProvinciasActivity.class);
        startActivityForResult(intentProv, SELECCIONA_PROVINCIA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELECCIONA_PROVINCIA && resultCode == RESULTADO_SELECCION_PROVINCIA){
            String ciudad =(String) data.getExtras().get("ciudad_elegida");
            int posicion =(int) data.getExtras().get("posicion_ciudad_elegida");

            TextView txtSel = findViewById(R.id.txtSel);
            txtSel.setText("La ciudad elegida es: " + ciudad + ", en la posicion: " + posicion);
        }
    }
}