package com.serbalced.pruebaintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("serbalced", "MainActivity.onCreate()");

        Button btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrancaActividadLogin();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("serbalced", "MainActivity.onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("serbalced", "MainActivity.onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("serbalced", "MainActivity.onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("serbalced", "MainActivity.onStop()");
    }

    @Override
    protected void onDestroy() {
        Log.d("serbalced", "MainActivity.onDestroy()");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("serbalced", "MainActivity.onRestart()");
    }

    public void arrancaActividadLogin(){
        //1º crear un objeto intent con la clase a instanciar
        Intent intentLogin = new Intent(this, LoginActivity.class);

        //2º arrancar la actividad
        startActivity(intentLogin);
    }
}